package carShopExtended;
//created by J.M.

public interface Rentable {

    Integer getMinRentDay();

    Double getPricePerDay();

}
