package carShopExtended;
//created by J.M.

public interface Sellable {

    Double getPrice();
}
