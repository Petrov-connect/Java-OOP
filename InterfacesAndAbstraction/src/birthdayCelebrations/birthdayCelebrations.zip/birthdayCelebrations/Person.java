package birthdayCelebrations;
//created by J.M.

public interface Person {

    String getName();
    int getAge();

}
