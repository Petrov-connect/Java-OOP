package ferrari;
//created by J.M.

public interface Car {

    String brakes();
    String gas();

}
