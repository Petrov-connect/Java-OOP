package carShop;
//created by J.M.

public interface Car {

    Integer TIRES = 4;

    String getModel();

    String getColor();

    Integer getHorsePower();

    String countryProduced();

}
