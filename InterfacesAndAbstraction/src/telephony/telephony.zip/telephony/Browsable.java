package telephony;
//created by J.M.

public interface Browsable {

    String browse();
}
