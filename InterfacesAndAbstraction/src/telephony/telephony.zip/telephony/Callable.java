package telephony;
//created by J.M.

public interface Callable {

    String call();
}
