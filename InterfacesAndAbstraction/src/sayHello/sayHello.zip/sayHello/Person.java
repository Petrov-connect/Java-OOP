package sayHello;
//created by J.M.

public interface Person {

    String getName();
    String sayHello();

}
