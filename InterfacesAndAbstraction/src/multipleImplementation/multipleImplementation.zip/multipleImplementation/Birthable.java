package multipleImplementation;
//created by J.M.

public interface Birthable {

    String getBirthDate();

}
