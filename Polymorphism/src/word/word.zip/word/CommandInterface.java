package word;
//created by J.M.

public interface CommandInterface {
    void init();
    void handleInput(String input);
}
