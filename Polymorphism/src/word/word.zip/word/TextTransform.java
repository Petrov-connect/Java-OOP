package word;
//created by J.M.

public interface TextTransform {
    void invokeOn(StringBuilder text, int startIndex, int endIndex);
}
