package vehicles;
//created by J.M.

public interface Vehicles {

    void drive(double distance);

    void refuel(double liters);

}
