package calculator;
//created by J.M.

public interface Operation {
    void addOperand(int operand);

    int getResult();

    boolean isCompleted();
}
