package cresla.entities.modules;


import cresla.interfaces.EnergyModule;

public abstract class EnergyModules  extends ModuleImpl implements EnergyModule {

    private int energyOutput;

    protected EnergyModules(int id, int energyOutput) {
        super(id);
        this.energyOutput = energyOutput;
    }

    @Override
    public int getEnergyOutput() {
        return 0;
    }
}
