package cresla.entities.modules;

public class CooldownSystem extends AbsorbingModules{

    public CooldownSystem(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }
}
