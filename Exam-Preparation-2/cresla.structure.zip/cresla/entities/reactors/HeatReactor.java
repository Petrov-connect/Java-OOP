package cresla.entities.reactors;

public class HeatReactor extends ReactorImpl{

    private final int heatReductionIndex;


    public HeatReactor(int id, int moduleCapacity, int heatReductionIndex) {
        super(id, moduleCapacity);
        this.heatReductionIndex = heatReductionIndex;
    }
}
