package cresla.entities.modules;
//created by J.M.

public class CooldownSystem extends AbsorbingModules{

    public CooldownSystem(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }
}
