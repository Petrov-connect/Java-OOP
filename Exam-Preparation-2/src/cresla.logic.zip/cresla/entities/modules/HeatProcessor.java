package cresla.entities.modules;
//created by J.M.

public class HeatProcessor extends AbsorbingModules{

    public HeatProcessor(int id, int heatAbsorbing) {

        super(id, heatAbsorbing);
    }
}
