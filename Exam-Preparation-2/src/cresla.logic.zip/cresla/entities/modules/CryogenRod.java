package cresla.entities.modules;
//created by J.M.

public class CryogenRod extends EnergyModules{

    public CryogenRod(int id, int energyOutput) {
        super(id, energyOutput);
    }
}
