package cresla.interfaces;
//created by J.M.

public interface EnergyModule extends Module {
    int getEnergyOutput();
}
