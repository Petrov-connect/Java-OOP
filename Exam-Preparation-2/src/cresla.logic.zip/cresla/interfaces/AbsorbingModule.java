package cresla.interfaces;
//created by J.M.

public interface AbsorbingModule extends Module {
    int getHeatAbsorbing();
}
