package cresla.interfaces;
//created by J.M.

public interface OutputWriter {
    void write(String output);

    void writeLine(String output);
}
