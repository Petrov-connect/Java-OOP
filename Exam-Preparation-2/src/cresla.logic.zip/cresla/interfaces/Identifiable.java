package cresla.interfaces;
//created by J.M.

public interface Identifiable {
    int getId();
}
