package onlineShop.models.products.peripherals;
//created by J.M.

import onlineShop.models.Product;

public interface Peripheral extends Product {
    String getConnectionType();
}
