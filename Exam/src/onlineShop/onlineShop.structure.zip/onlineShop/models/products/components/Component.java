package onlineShop.models.products.components;
//created by J.M.

import onlineShop.models.Product;

public interface Component extends Product {

    int getGeneration();
}
