package onlineShop.io.interfaces;
//created by J.M.

import java.io.IOException;

public interface InputReader {
    String readLine() throws IOException;
}
