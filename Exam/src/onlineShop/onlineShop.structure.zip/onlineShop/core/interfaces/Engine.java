package onlineShop.core.interfaces;
//created by J.M.

public interface Engine extends Runnable {
}
