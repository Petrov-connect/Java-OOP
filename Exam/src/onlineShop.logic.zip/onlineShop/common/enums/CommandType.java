package onlineShop.common.enums;
//created by J.M.

public enum CommandType {
    AddComputer,
    AddPeripheral,
    RemovePeripheral,
    AddComponent,
    RemoveComponent,
    BuyComputer,
    BuyBestComputer,
    GetComputerData,
    Close
}
