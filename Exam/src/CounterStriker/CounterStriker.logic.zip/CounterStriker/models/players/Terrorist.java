package CounterStriker.models.players;
//created by J.M.

import CounterStriker.models.guns.Gun;

public class Terrorist extends PlayerImpl{

    public Terrorist(String username, int health, int armor, Gun gun) {

        super(username, health, armor, gun);
    }
}
