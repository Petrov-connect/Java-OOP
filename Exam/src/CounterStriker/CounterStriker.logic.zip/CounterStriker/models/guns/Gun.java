package CounterStriker.models.guns;
//created by J.M.

public interface Gun {
    String getName();

    int getBulletsCount();

    int fire();
}
