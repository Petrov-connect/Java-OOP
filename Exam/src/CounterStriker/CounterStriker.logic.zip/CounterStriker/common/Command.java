package CounterStriker.common;
//created by J.M.

public enum Command {
    AddGun,
    AddPlayer,
    Report,
    StartGame,
    Exit
}
