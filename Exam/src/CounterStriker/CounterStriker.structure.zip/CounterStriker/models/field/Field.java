package CounterStriker.models.field;
//created by J.M.

import CounterStriker.models.players.Player;

import java.util.Collection;

public interface Field {

    String start(Collection<Player> players);
}
