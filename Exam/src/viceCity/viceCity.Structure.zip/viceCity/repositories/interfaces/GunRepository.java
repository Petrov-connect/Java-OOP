package viceCity.repositories.interfaces;
//created by J.M.

import viceCity.models.guns.Gun;

import java.util.Collection;
import java.util.Collections;

public class GunRepository implements Repository{

    private Collection<Gun> models;

    public GunRepository(Collection<Gun> models) {
        this.models =
                 Collections.unmodifiableCollection(models);
    }

    @Override
    public Collection getModels() {
        return null;
    }

    @Override
    public void add(Object model) {

    }

    @Override
    public boolean remove(Object model) {
        return false;
    }

    @Override
    public Object find(String name) {
        return null;
    }
}
