package bakery.entities.drinks.interfaces;
//created by J.M.

public interface Drink {
    String getName();

    int getPortion();

    double getPrice();

    String getBrand();
}
