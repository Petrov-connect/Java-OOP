package bakery.entities.bakedFoods.interfaces;
//created by J.M.

public interface BakedFood {
    String getName();

    double getPortion();

    double getPrice();
}
