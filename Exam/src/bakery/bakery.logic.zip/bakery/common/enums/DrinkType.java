package bakery.common.enums;
//created by J.M.

public enum DrinkType {
    Tea,
    Water
}
