package bakery.common.enums;
//created by J.M.

public enum BakedFoodType {
    Bread,
    Cake
}
