package bakery.common.enums;
//created by J.M.

public enum Commands {
    AddFood,
    AddDrink,
    AddTable,
    ReserveTable,
    OrderFood,
    OrderDrink,
    LeaveTable,
    GetFreeTablesInfo,
    GetTotalIncome,
    END
}
