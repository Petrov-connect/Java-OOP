package bakery.common.enums;
//created by J.M.

public enum TableTYpe {
    InsideTable,
    OutsideTable
}
