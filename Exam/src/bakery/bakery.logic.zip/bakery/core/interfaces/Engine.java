package bakery.core.interfaces;
//created by J.M.

public interface Engine {
    void run();
}
