package easterRaces.repositories;
//created by J.M.

import easterRaces.entities.drivers.Driver;
import easterRaces.repositories.interfaces.Repository;

import java.util.Collection;
import java.util.LinkedList;

public class DriverRepository<T>implements Repository<Driver> {

    private Collection<Driver> models;

    public DriverRepository() {
        this.models = new LinkedList<>();
    }

    @Override
    public Driver getByName(String name) {
        return null;
    }

    @Override
    public Collection<Driver> getAll() {
        return null;
    }

    @Override
    public void add(Driver model) {

    }

    @Override
    public boolean remove(Driver model) {
        return false;
    }
}
