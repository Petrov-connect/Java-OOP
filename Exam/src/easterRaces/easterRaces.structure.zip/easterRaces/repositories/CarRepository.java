package easterRaces.repositories;
//created by J.M.

import easterRaces.entities.cars.Car;
import easterRaces.repositories.interfaces.Repository;

import java.util.Collection;
import java.util.LinkedList;

public class CarRepository<T> implements Repository<Car> {

    private Collection<Car>models;

    public CarRepository() {
        this.models = new LinkedList<>();
    }

    @Override
    public Car getByName(String name) {
        return null;
    }

    @Override
    public Collection<Car> getAll() {
        return null;
    }

    @Override
    public void add(Car model) {

    }

    @Override
    public boolean remove(Car model) {
        return false;
    }
}
