package easterRaces.repositories;
//created by J.M.

import easterRaces.repositories.interfaces.Repository;

import java.util.Collection;
import java.util.LinkedList;


public class RaceRepository<Race> implements Repository<Race> {

    private Collection<Race> models;

    public RaceRepository() {
        this.models = new LinkedList<>();
    }

    @Override
    public Race getByName(String name) {
        return null;
    }

    @Override
    public Collection<Race> getAll() {
        return null;
    }

    @Override
    public void add(Race model) {

    }

    @Override
    public boolean remove(Race model) {
        return false;
    }
}
