package easterRaces.io.interfaces;
//created by J.M.

public interface OutputWriter {
    void writeLine(String text);
}
