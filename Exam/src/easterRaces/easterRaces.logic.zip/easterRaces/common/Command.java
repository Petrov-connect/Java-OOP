package easterRaces.common;
//created by J.M.

public enum Command {
    CreateDriver,
    CreateCar,
    AddCarToDriver,
    AddDriverToRace,
    CreateRace,
    StartRace,
    End
}
