package aquarium.models.decorations;
//created by J.M.

public interface Decoration {
    int getComfort();

    double getPrice();
}
