package aquarium.models.fish;
//created by J.M.
public interface Fish {

    void setName(String name);

    void eat();

    int getSize();

    String getName();

    double getPrice();
}
