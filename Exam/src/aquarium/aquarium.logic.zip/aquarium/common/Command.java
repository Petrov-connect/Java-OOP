package aquarium.common;
//created by J.M.

public enum Command {

    AddAquarium,
    AddDecoration,
    InsertDecoration,
    AddFish,
    FeedFish,
    CalculateValue,
    Report,
    Exit

}
