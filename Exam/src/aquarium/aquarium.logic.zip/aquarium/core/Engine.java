package aquarium.core;
//created by J.M.

public interface Engine extends Runnable {
}

