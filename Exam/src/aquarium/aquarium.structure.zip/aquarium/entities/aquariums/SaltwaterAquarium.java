package aquarium.entities.aquariums;

public class SaltwaterAquarium extends BaseAquarium{

    private static final int capacity_const = 50;
    public SaltwaterAquarium(String name) {
        super(name, capacity_const);
    }
}
