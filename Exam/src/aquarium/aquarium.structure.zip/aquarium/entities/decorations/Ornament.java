package aquarium.entities.decorations;

public class Ornament extends BaseDecoration{

    private static final int comfort_const = 1;
    private static final double price_const = 5;

    public Ornament() {
        super(comfort_const, price_const);
    }
}
