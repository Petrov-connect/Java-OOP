package PointInRectangle;
//created by J.M.

public class Main {

    public static void main(String[] args) {
        Reader reader = new Reader();
        int[] rectangleInfo = reader.readIntegerArray("\\s+");
        Rectangle rectangle = GeometryFactory.createRectangle(rectangleInfo);
        int countNextLines = reader.readInteger();
        while (countNextLines-- > 0) {
            int[] pointInfo = reader.readIntegerArray("\\s+");
            System.out.println(rectangle.contains(GeometryFactory.createPoint2D(pointInfo)));
        }
    }
}
