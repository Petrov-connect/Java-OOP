package CardSuit;
//created by J.M.

public enum Suit {

    CLUBS, DIAMONDS, HEARTS, SPADES
}
