package multipleInheritance;
//created by J.M.

public class Animal {

    public void eat(){
        System.out.println("eating…");
    }
}
