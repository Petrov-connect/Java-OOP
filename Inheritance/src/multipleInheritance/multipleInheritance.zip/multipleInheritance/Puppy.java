package multipleInheritance;
//created by J.M.

public class Puppy extends Dog{

    public void weep(){
        System.out.println("weeping…");
    }
}
