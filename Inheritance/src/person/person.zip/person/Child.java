package person;
//created by J.M.

public class Child extends Person{

    public Child(String name, int age) {
        super(name, age);
    }
}
