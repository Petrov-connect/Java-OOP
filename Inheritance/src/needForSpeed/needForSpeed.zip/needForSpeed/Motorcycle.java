package needForSpeed;
//created by J.M.

public class Motorcycle extends Vehicle{

    public Motorcycle(double fuel, int horsePower) {
        super(fuel, horsePower);
    }
}
