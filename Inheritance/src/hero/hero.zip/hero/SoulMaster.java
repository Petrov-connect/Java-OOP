package hero;
//created by J.M.
public class SoulMaster extends DarkWizard{
    public SoulMaster(String username, int level) {
        super(username, level);
    }
}
