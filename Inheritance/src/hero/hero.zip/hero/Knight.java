package hero;
//created by J.M.

public class Knight extends Hero{
    public Knight(String username, int level) {
        super(username, level);
    }
}
