package hero;
//created by J.M.

public class Wizard extends Hero{
    public Wizard(String username, int level) {
        super(username, level);
    }
}
