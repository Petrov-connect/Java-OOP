package zoo;
//created by J.M.

public class Bear extends Mammal{
    public Bear(String name) {
        super(name);
    }
}
