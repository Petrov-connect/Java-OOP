package zoo;
//created by J.M.

public class Reptile extends Animal{

    public Reptile(String name) {
        super(name);
    }
}
