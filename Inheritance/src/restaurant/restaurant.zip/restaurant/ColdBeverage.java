package restaurant;
//created by J.M.

import java.math.BigDecimal;

public class ColdBeverage extends Beverage{

    public ColdBeverage(String name, BigDecimal price, double milliliters) {
        super(name, price, milliliters);
    }
}
