package hierarchicalInheritance;
//created by J.M.

public class Cat extends Animal{

    public void meow(){
        System.out.println("meowing…");
    }
}
