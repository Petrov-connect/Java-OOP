package barracksWars.interfaces;
//created by J.M.

public interface Unit extends Destroyable, Attacker {
}
