package barracksWars.interfaces;
//created by J.M.

public interface Executable {

	String execute();

}
