//created by J.M.

import java.lang.reflect.Method;
import java.util.Set;
import java.util.TreeSet;

public class Main {

    public static void main(String[] args) {

        Class<Reflection>reflection = Reflection.class;
        Method[] methods = reflection.getDeclaredMethods();
        Set<String> getters = new TreeSet<>();
        Set<String> setters = new TreeSet<>();
        for (Method method : methods) {
            if(method.getName().contains("get")){
                getters.add(String.format("%s will return class %s",method.getName(),method.getReturnType().getName()));
            }else if(method.getName().contains("set")){
                setters.add(String.format("%s and will set field of class %s",method.getName()
                        ,method.getParameters()[0].getType().getName()));
            }
        }
        getters.forEach(System.out::println);
        setters.forEach(System.out::println);
    }
}
