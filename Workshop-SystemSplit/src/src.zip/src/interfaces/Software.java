package interfaces;
//created by J.M.

public interface Software {

    String getName();

    int getCapacityConsumption();

    int getMemoryConsumption();
}
