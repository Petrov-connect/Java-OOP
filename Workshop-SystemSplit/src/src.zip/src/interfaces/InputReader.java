package interfaces;
//created by J.M.

public interface InputReader {
    String readLine();
}
