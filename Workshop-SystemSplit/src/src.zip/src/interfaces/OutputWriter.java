package interfaces;
//created by J.M.

public interface OutputWriter {
    void write(String output);
}
