//created by J.M.

import manager.MyManager;

public class Main {

    public static void main(String[] args) {

        MyManager manager = new MyManager();
        manager.run();
    }
}
